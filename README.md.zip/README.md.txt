Project Overview


Sprint 4 Project
This presentation is intended for use by SuperStore to assess store operations, increase profits and avoid bankruptcy. 
Part 1 identifies Profit and Loss Centers 
Part 2 assess the best months and states in which to advertise
Part 3 analyzes returns by product, customer and state.

Links to Project 
All Visuals	https://public.tableau.com/app/profile/heather.looby/vizzes	
Part 1(1) 	https://public.tableau.com/app/profile/heather.looby/viz/Sprint4ProjectPart11V1_17113234766400/Sprint4ProjectPart11V1
Part 1(2)	https://public.tableau.com/app/profile/heather.looby/viz/Sprint4ProjectPart12V1_17113235216980/Sprint4ProjectPart12V1
Part 1(3)	https://public.tableau.com/app/profile/heather.looby/viz/Sprint4ProjectPart13V1_17113235948790/Sprint4ProjectPart13V1
Part 2		https://public.tableau.com/app/profile/heather.looby/viz/Sprint4ProjectPart2V1_17113236578230/Sprint4ProjectPart2V1
Part 3		https://public.tableau.com/app/profile/heather.looby/viz/Sprint4ProjectPart3V1/Sprint4ProjectPart3V1

Supporting data and documentation available. 